PCA and Logistic Regression on Breast Cancer Dataset


Project Description

This project showcases the use of Principal Component Analysis (PCA) to extract key variables from the breast cancer dataset provided by sklearn.datasets. It also includes the implementation of logistic regression to predict the target variable using the data reduced to two PCA components.

Requirements
- Python 
- Jupyter notebook
- Requires Libraries: pandas, numpy, seaborn, matplotlib, scikit-learn


Importing Required Libraries

   import pandas as pd
   import numpy as np
   import seaborn as sns
   import matplotlib.pyplot as plt
   from sklearn.preprocessing import StandardScaler
   from sklearn.decomposition import PCA

   Load and Explore Dataset:

   cancer = load_breast_cancer()
   df_cancer = pd.DataFrame(cancer['data'], columns=cancer['feature_names'])
   df_cancer.info()
   df_cancer.describe()
   df_cancer.shape

Logistic Regression for Prediction:

    target = pd.Series(cancer['target'], name='target')
    df_principal= pd.concat([df_principal, target], axis=1)

    X = df_principal[['PCA1', 'PCA2']]
    y = df_principal['target']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=100)
    model_log = LogisticRegression()
    model_log.fit(X_train, y_train)
    predictions = model_log.predict(X_test)
    print(classification_report(y_test, predictions))
    print(confusion_matrix(y_test, predictions))
Results

Classification Report:
      precision    recall  f1-score   support

           0       0.95      0.91      0.93       107
           1       0.95      0.97      0.96       178

    accuracy                           0.95       285
   macro avg       0.95      0.94      0.94       285
weighted avg       0.95      0.95      0.95       285


Interpretation:

Accuracy Rate: The model achieves a 95% accuracy rate, indicating strong overall performance. Benign Tumor Predictions: With 94% precision and 95% recall, the model reliably identifies benign tumors and minimizes misclassification as malignant. Malignant Tumor Predictions: The model demonstrates 97% precision and 95% recall, effectively identifying malignant tumors with minimal misclassification as benign.


Author Etimbuk Bassey  Data Analyst at the Anderson Cancer Centre.
